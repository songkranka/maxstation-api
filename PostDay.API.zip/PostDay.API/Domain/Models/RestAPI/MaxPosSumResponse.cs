﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PostDay.API.Domain.Models.RestAPI
{
    public class MaxPosSumResponse
    {
        public string shopid { get; set; }
        public string summary { get; set; }
    }
}
