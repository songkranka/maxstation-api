﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PostDay.API.Domain.Models.Soap
{
    public class CustomerAmount
    {
        public decimal amt;
        public string legcustcode;
        public string ORI_SHOP_CODE;
    }
}
